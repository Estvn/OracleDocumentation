SELECT * FROM COPY_D_CDS;

CREATE TABLE COPY_D_CDS AS (SELECT * FROM D_CDS);

DESCRIBE COPY_D_CDS;

DECLARE
    v_contar NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_contar FROM COPY_D_CDS;
    
    IF v_contar = 0 THEN
        INSERT INTO COPY_D_CDS VALUES(99, 'Baladas de los 80', 'Varios', '1980');
    END IF;
    DBMS_OUTPUT.PUT_LINE('La tabla contiene: ' || v_contar || ' registros.');
END;

DELETE FROM COPY_D_CDS;


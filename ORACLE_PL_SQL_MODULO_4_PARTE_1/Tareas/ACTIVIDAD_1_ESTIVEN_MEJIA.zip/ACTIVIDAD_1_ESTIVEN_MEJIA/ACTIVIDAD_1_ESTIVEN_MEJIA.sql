-- EJERCICIO 1
DECLARE
    v_date DATE := SYSDATE;
BEGIN

    DBMS_OUTPUT.PUT_LINE('La fecha dentro de 6 meses es: ' || TO_CHAR(ADD_MONTHS(v_date,6), 'YYYY-MON-DD'));
END;

-- EJERCICIO 2
DECLARE
    v_nombre VARCHAR2(20) := 'Estiven';
    v_apellido VARCHAR2(20) := 'Mej�a';
    v_edad INTEGER := 23;
BEGIN
    DBMS_OUTPUT.PUT_LINE(' Nombre: ' || v_nombre || ' ' || v_apellido || ' | Edad: ' || v_edad);
END;

-- EJERCICIO 3
DECLARE
    v_fecha_nacimiento DATE := TO_DATE('2001-08-09', 'YYYY-MM-DD');
    v_fecha_actual DATE := SYSDATE;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Meses transcurridos: ' || TRUNC(MONTHS_BETWEEN(v_fecha_actual, v_fecha_nacimiento)));
END;

CREATE OR REPLACE FUNCTION dividir(n1 number, n2 number)
RETURN NUMBER
IS BEGIN    
    RETURN ROUND(n1/n2, 2);

EXCEPTION 
    WHEN ZERO_DIVIDE THEN
        DBMS_OUTPUT.PUT_LINE('No puede dividir entre cero');
        RETURN 0;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error gen�rico');
        RETURN 0;
END dividir;
    
    
BEGIN
    DBMS_OUTPUT.PUT_LINE(dividir(25,0));
END;

SET SERVEROUTPUT ON;
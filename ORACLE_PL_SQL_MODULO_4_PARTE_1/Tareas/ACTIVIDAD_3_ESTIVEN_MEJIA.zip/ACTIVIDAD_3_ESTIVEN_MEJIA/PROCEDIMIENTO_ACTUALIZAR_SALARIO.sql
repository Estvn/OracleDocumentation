CREATE TABLE COPY_EMP AS (SELECT * FROM EMPLOYEES);

DESCRIBE COPY_EMP;

SELECT 
    employee_id, (first_name || ' ' || last_name) as "name", department_id, salary
FROM copy_emp 
WHERE department_id IN(10, 80);

CREATE OR REPLACE PROCEDURE actualizar_salario 
IS 
    CURSOR act_sal IS
        SELECT employee_id, department_id, salary FROM copy_emp
        WHERE department_id IN(10,80)
        FOR UPDATE NOWAIT;
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    FOR v_act_sal IN act_sal LOOP
        CASE v_act_sal.department_id
            WHEN 10 THEN
                UPDATE COPY_EMP 
                    SET salary = 15000
                    WHERE CURRENT OF act_sal;
            WHEN 80 THEN
                UPDATE COPY_EMP
                    SET salary = 20000
                        WHERE CURRENT OF act_sal;
        END CASE;
    END LOOP;
    COMMIT;
EXCEPTION 
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Hubo un problema encontrando un dato...');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Hubo un problema...');
        ROLLBACK;
END actualizar_salario;
    
BEGIN       
    actualizar_salario;
END;
